 require([
         'jquery',
         'splunkjs/mvc',
         'splunkjs/mvc/simplexml/ready!'
     ], function ($, mvc) {
     var tokens = mvc.Components.get("submitted");

     $('#details').on("click", function (){
         tokens.set("showdetail","true");
     });
     $('#details2').on("click", function (){
         tokens.set("showdetail2","true");
     });
     $('#details3').on("click", function (){
         tokens.set("showdetail3","true");
     }); 
	
$(document).on('click', '#details',function (){
console.log("insidehypedetailsfunction")
tokens.set("showdetail1","true");
});

$('#outofareatablebutton').on("click", function (){
tokens.unset("showdetail1","true");
});



 });