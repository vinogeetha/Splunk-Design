require([
	'jquery',
	'splunkjs/mvc',
	'splunkjs/mvc/simplexml/ready!'
], function ($, mvc) {
	var tokens = mvc.Components.get("submitted");
	// Access the "default" token model
    	var tokensDefault = mvc.Components.get("default");

    // Retrieve the value of a token $mytoken$
    	


    tokens.set("showpanel1", "true");
    tokens.set("showpanel2", "true");
    tokens.unset("showpanel2");
    $("#panel_row").css('width', '100%');
    $("#forwardclick").css("pointer-events","none");


    $("#forwardclick").css("fill","#d8d1d1");
	$("#backwardclick").css("cursor","pointer");

	$("#forwardclick").on("click", function (){
		var tokenValue1 = tokens.get("showpanel2");

		if(tokenValue1==false || tokenValue1==undefined){
			 $("#panel_row").css('width', '100%');


			tokens.set("showpanel2", "true");
			tokens.unset("showpanel3");
			 $("#forwardclick").css("pointer-events","auto");
		
		 $("#forwardclick").css("fill","#303030");
		 $("#forwardclick").css("cursor","pointer");

		}
		else{
			 $("#panel_row").css('width', '100%');

			tokens.set("showpanel1", "true");
			tokens.unset("showpanel2");
			tokens.unset("showpanel3");

			 $("#forwardclick").css("pointer-events","none");
			 $("#forwardclick").css("fill","#d8d1d1");
			}

		//tokens.set("showpanel1", "true");
		//tokens.unset("showpanel2");
		//tokens.unset("showpanel3");


		 $("#panel_row").css('width', '100%');
		 //$("#forwardclick").css("pointer-events","none");
		 $("#backwardclick").css("pointer-events","auto");
		 //$("#forwardclick").css("fill","#d8d1d1");
		 $("#backwardclick").css("fill","#303030");
		 $("#backwardclick").css("cursor","pointer");
	});

	$("#backwardclick").on("click", function (){
		tokens.unset("showpanel1");
		
		var tokenValue = tokens.get("showpanel2");
		console.log(tokenValue)
		if(tokenValue==false || tokenValue==undefined){
			 $("#panel_row").css('width', '100%');


			tokens.set("showpanel2", "true");
			tokens.unset("showpanel3");
		}
		else{
			 $("#panel_row").css('width', '33%');

			tokens.set("showpanel3", "true");
			tokens.unset("showpanel2");
			 $("#backwardclick").css("pointer-events","none");
			 $("#backwardclick").css("fill","#d8d1d1");
			}
				 $("#forwardclick").css("pointer-events","auto");
		
		 $("#forwardclick").css("fill","#303030");
		 $("#forwardclick").css("cursor","pointer");
		
		 				
		
		 
		
	});



});
