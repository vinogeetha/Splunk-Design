require([
    'underscore',
    'jquery',
    'splunkjs/mvc',
    'splunkjs/mvc/tableview',
    'splunkjs/mvc/simplexml/ready!'
], function(_, $, mvc, TableView) {
	
	var CustomRangeRenderer = TableView.BaseCellRenderer.extend({
        canRender: function(cell) {
	     console.log(cell);
            // Enable this custom cell renderer for Aug	 field
            return _(["Aug'20"]).contains(cell.field);
        },
        render: function($td, cell) {
            // Add a class to the cell based on the returned value
            var value = cell.value;
		
            // Apply interpretation for Aug'20 field
           
            if (cell.field === "Aug'20") {
                //Add range class based on cell values.
                if (cell.index == 1 ) {
                    if (value <5000 ) 
                                    $td.addClass("range-cell").addClass("range-purple1");
                    if (value >5000 ) 
                                    $td.addClass("range-cell").addClass("range-purple2");
                }
                if (cell.index == 2 ) {
                    if (value <3000 ) 
                                    $td.addClass("range-cell").addClass("range-purple1");
                    if (value >1000 ) 
                                    $td.addClass("range-cell").addClass("range-purple2");
                }
                if (cell.index == 3 ) {
                    if (value <300 ) 
                                    $td.addClass("range-cell").addClass("range-purple1");
                    if (value >100 ) 
                                    $td.css('background-color', '#209cee1');
                }
                            
            }

            // Update the cell content with string value
            $td.text(value).addClass('string');
        }
    });

    mvc.Components.get('table30').getVisualization(function(tableView) {

        tableView.on('rendered', function() {
            // Add a delay to ensure Custom Render applies to row without getting overridden with built in reder.           
            setTimeout(function(){  
                // Apply class of the cells to the parent row in order to color the whole row
                tableView.$el.find('td.range-cell').each(function() {
                    $(this).parents('tr').addClass(this.className);
                });
            },100);
        });

        // Add custom cell renderer, the table will re-render automatically.
        tableView.addCellRenderer(new CustomRangeRenderer());
    });
	 
});