 require([
         'jquery',
         'splunkjs/mvc',
         'splunkjs/mvc/simplexml/ready!'
     ], function ($, mvc) {
     var tokens = mvc.Components.get("submitted");
      $('#filebutton').on("click", function (){
         tokens.unset("kpi_file","true");
     });
     $('#cpubutton').on("click", function (){
         tokens.unset("kpi_cpu","true");
     });
     $('#workbutton').on("click", function (){
         tokens.unset("kpi_work","true");
     });
     $('#memorybutton').on("click", function (){
         tokens.unset("memory","true");
     });
     $('#consistencybutton').on("click", function (){
         tokens.unset("consistency","true");
     });
     $('#runtimebutton').on("click", function (){
         tokens.unset("runtime","true");
     }); 
     $('#systembutton').on("click", function (){
         tokens.unset("systemlogs","true");
     }); 
     $('#lockbutton').on("click", function (){
         tokens.unset("lockentries","true");
     }); 
     $('#backgroundbutton').on("click", function (){
         tokens.unset("backgroundjobs","true");
     }); 
     $('#spoolbutton').on("click", function (){
         tokens.unset("spoolerrors","true");
     });
      $('#eccbutton').on("click", function (){
         tokens.unset("eccqueue","true");
     });
      $('#redwoodbutton').on("click", function (){
         tokens.unset("redwoodjobs","true");
     });
      $('#ccmsbutton').on("click", function (){
         tokens.unset("ccmsagents","true");
     });
      $('#smdabutton').on("click", function (){
         tokens.unset("smdagents","true");
     });
      $('#willybutton').on("click", function (){
         tokens.unset("willyenterprise","true");
     });
      $('#enterprisebutton').on("click", function (){
         tokens.unset("enterpriseportal","true");
 
     }); 
      $('#conversationbutton').on("click", function (){
         tokens.unset("conversation","true");
 
     }); 
      $('#activebutton').on("click", function (){
         tokens.unset("active","true");
 
     }); 
      $('#engagedbutton').on("click", function (){
         tokens.unset("engaged","true");
 
     }); 
      $('#newbutton').on("click", function (){
         tokens.unset("new","true");
 
     }); 
     $('#badbutton').on("click", function (){
         tokens.unset("bad","true");
 
     }); 
     $('#failurebutton').on("click", function (){
         tokens.unset("failure","true");
 
     }); 
      $('#workrunbutton').on("click", function (){
         tokens.unset("workrun","true");
 
     }); 
      $('#memorycheckbutton').on("click", function (){
         tokens.unset("memorycheck","true");
 
     }); 
      $('#updatesystem').on("click", function (){
         tokens.unset("updatesystem","true");
 
     }); 
      $('#updaterequestbutton').on("click", function (){
         tokens.unset("updaterequest","true");
 
     }); 
      $('#appserverbutton').on("click", function (){
         tokens.unset("appserver","true");
 
     }); 
       $('#applicationbutton').on("click", function (){
         tokens.unset("application","true");
 
     }); 
     $('#workprocessbutton').on("click", function (){
         tokens.unset("workprocess","true");
 
     });  
       $('#availabilitybutton').on("click", function (){
         tokens.unset("availability_trend"); 
     }); 
     $('#responsebutton').on("click", function (){
         tokens.unset("response_trend");
 
     }); 
  $('#incidentdetailbutton').on("click", function (){
         tokens.unset("showincidentdetails");
         tokens.unset("closedtrendanalytics");
         tokens.unset("opentrendanalytics");
         tokens.unset("showincidentdesc1");
         tokens.unset("showincidentdesc2");

     }); 
     $('#incidentdetail_optobutton').on("click", function (){
         tokens.unset("showincidentdetailstoday");
         tokens.unset("showincidentdesc1");
         tokens.unset("showincidentdesc2");
          });

     $('#incidentdetailbutton1').on("click", function (){
         tokens.unset("showincidentdetails");
         tokens.unset("closedtrendanalytics");
         tokens.unset("opentrendanalytics");
         tokens.unset("showincidentdesc1");
         tokens.unset("showincidentdesc2");
     }); 
     $('#incidentdetailbutton2').on("click", function (){
         tokens.unset("showincidentdetailstoday");
         tokens.unset("showincidentdesc1");
         tokens.unset("showincidentdesc2");
          });

      $('#availabilitybutton1').on("click", function (){
         tokens.unset("availability_trend1");
 
     }); 
     $('#responsebutton1').on("click", function (){
         tokens.unset("response_trend1");
 
     }); 
      $('#availabilitybutton2').on("click", function (){
         tokens.unset("availability_trend2");
 
     }); 
     $('#responsebutton2').on("click", function (){
         tokens.unset("response_trend2");
 
     }); 
      $('#availabilitybutton3').on("click", function (){
         tokens.unset("availability_trend3");
 
     }); 
     $('#responsebutton3').on("click", function (){
         tokens.unset("response_trend3");
 
     }); 
      $('#availabilitybutton4').on("click", function (){
         tokens.unset("availability_trend4");
 
     }); 
     $('#responsebutton4').on("click", function (){
         tokens.unset("response_trend4");
 
     }); 
       $('#availabilitybutton5').on("click", function (){
         tokens.unset("availability_trend5");
 
     }); 
     $('#responsebutton5').on("click", function (){
         tokens.unset("response_trend5");
 
     }); 
      $('#availabilitybutton6').on("click", function (){
         tokens.unset("availability_trend6");
 
     }); 
     $('#responsebutton6').on("click", function (){
         tokens.unset("response_trend6");
 
     }); 
  $('#availabilitybutton7').on("click", function (){
         tokens.unset("availability_trend7");
 
     }); 
     $('#responsebutton7').on("click", function (){
         tokens.unset("response_trend7");
 
     }); 
  $('#availabilitybutton8').on("click", function (){
         tokens.unset("availability_trend8");
 
     }); 
     $('#responsebutton8').on("click", function (){
         tokens.unset("response_trend8");
 
     }); 
  $('#availabilitybutton10').on("click", function (){
         tokens.unset("availability_trend10");
 
     }); 
     $('#responsebutton10').on("click", function (){
         tokens.unset("response_trend10");
 
     }); 
  $('#availabilitybutton11').on("click", function (){
         tokens.unset("availability_trend11");
 
     }); 
     $('#responsebutton11').on("click", function (){
         tokens.unset("response_trend11");
 
     }); 
      $('#serverclose').on("click", function (){
         tokens.unset("showservertrend");
 
     }); 
     $('#rfcclose').on("click", function (){
         tokens.unset("showrfctrend");
 
     }); 
 	$('#httpclose').on("click", function (){
         tokens.unset("showhttptrend");
 
     }); 
 	$('#dbavailabilitybutton').on("click", function (){
         tokens.unset("showavailabletrend");
 
     }); 

 	$('#dbresponsebutton').on("click", function (){
         tokens.unset("showresponsetrend");
 
     }); 

      $('#dbavailabilitybutton').on("click", function (){
         tokens.unset("showavailabletrend");
 
     }); 

 	$('#httptrendclose').on("click", function (){
         tokens.unset("showhttpresponsetrend");
 
     }); 
 	$('#keystorebutton').on("click", function (){
         tokens.unset("tok_is_expiring");
 
     }); 
	$('#channelbutton').on("click", function (){
         tokens.unset("channel_show");
 
     }); 
      $('#incidentdesc_button').on("click", function (){
         tokens.unset("showincidentdesc");
 
     }); 
 $('#publicationbutton').on("click", function (){
         tokens.unset("show_panel39");
 
     });
$('#subscriptiontionbutton').on("click", function (){
         tokens.unset("show_panel40");
 
     });


$(document).on('click', '#details',function (){
console.log("insidehypedetailsfunction")
tokens.set("showdetail1","true");
});

$('#outofareatablebutton').on("click", function (){
tokens.unset("showdetail1","true");
});

     $(document).on('click', '#details2',function (){
console.log("insidehypedetailsfunction")
tokens.set("showdetail2","true");
});

$('#geographybutton').on("click", function (){
tokens.unset("showdetail2","true");
});

     $(document).on('click', '#details3',function (){
console.log("insidehypedetailsfunction")
tokens.set("showdetail3","true");
});

$('#geo1button').on("click", function (){
tokens.unset("showdetail3","true");
});
$('#failedbutton').on("click", function (){
tokens.unset("faileddetails","true");
});
$('#status1').on("click", function (){
tokens.unset("statustoken","true");
});


     $(document).on('click', '#details4',function (){
console.log("insidehypedetailsfunction")
tokens.set("showdetail4","true");
});

$('#ooabutton').on("click", function (){
tokens.unset("showdetail4","true");
});

     $(document).on('click', '#details5',function (){
console.log("insidehypedetailsfunction")
tokens.set("showdetail5","true");
});

$('#consloginbutton').on("click", function (){
tokens.unset("showdetail5","true");
});
 $('#runtimebutton').on("click", function (){
         tokens.unset("user_token","true");
     });
$('#jobbutton').on("click", function (){
         tokens.unset("job_overview","true");
     });
$('#lockentrybutton').on("click", function (){
         tokens.unset("lock_entry","true");
     });
$('#systemlogbutton').on("click", function (){
         tokens.unset("status","true");
     });
$('#rfcbutton').on("click", function (){
         tokens.unset("rfc_overview","true");
     });

$('#rfcstatusbutton').on("click", function (){
         tokens.unset("rfc_status","true");
     });
$('#parentbutton').on("click", function (){
         tokens.unset("parent_status","true");
     });

$('#messagebutton').on("click", function (){
         tokens.unset("message_monitoring","true");
     });





           
 });	