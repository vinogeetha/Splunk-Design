require([
     'jquery',
     'splunkjs/mvc',
     'splunkjs/mvc/simplexml/ready!'
 ], function($, mvc){
         $('#multi').on("change",function(){
                 var multi1 = mvc.Components.get("multi");
                 var tokens = mvc.Components.getInstance("default");
                 var mytoken = tokens.get("multi")
console.log("mytoken",mytoken)
                  if (mytoken.length > 1 && mytoken.includes("All"))
                 {
                    console.log("value",mytoken)
                 }
				 else{
					console.log("value11",mytoken)
				 }


 }); 
 });