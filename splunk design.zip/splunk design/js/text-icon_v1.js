 require([
    'underscore',
    'jquery',
    'splunkjs/mvc',
    'splunkjs/mvc/tableview',
    'splunkjs/mvc/simplexml/ready!'
], function(_, $, mvc, TableView) {
    var CustomIconRenderer = TableView.BaseCellRenderer.extend({
        canRender: function(cell) {
            return cell.field === 'Status';
        },
        render: function($td, cell) {
            var Status = cell.value;
            // Compute the icon base on the field value
            var icon;
                  if(Status == "Success") {
                icon = 'check-circle';
            }    else if(Status == "Warning") {
                icon = 'error';
            } else if(Status == "In Progress") {
                icon = 'rotate-counter';
            } else if(Status == "Not Started") {
                icon = 'clock';
            }  else if(Status == "Normal") {
                icon = 'check-circle';
            } else if(Status == "Critical") {
                icon = 'x-circle';
            } else if(Status == "Skip") {
                icon = ' ';
            }
               else {
                icon = 'x-circle';
            }
            // Create the icon element and add it to the table cell
            $td.addClass('icon-inline numeric').html(_.template('<i class="icon-<%-icon%>"></i> ', {
                icon: icon,
                text: cell.value
            }));
        }
    });
    mvc.Components.get('table1').getVisualization(function(tableView){
        // Register custom cell renderer, the table will re-render automatically
        tableView.addCellRenderer(new CustomIconRenderer());
    });
        mvc.Components.get('table2').getVisualization(function(tableView){
         tableView.addCellRenderer(new CustomIconRenderer());
    });
    
    mvc.Components.get('table3').getVisualization(function(tableView){
         tableView.addCellRenderer(new CustomIconRenderer());
    });
    
    mvc.Components.get('table4').getVisualization(function(tableView){
         tableView.addCellRenderer(new CustomIconRenderer());
    });
    
    mvc.Components.get('table5').getVisualization(function(tableView){
         tableView.addCellRenderer(new CustomIconRenderer());
    });
    mvc.Components.get('table6').getVisualization(function(tableView){
         tableView.addCellRenderer(new CustomIconRenderer());
    });
    
    mvc.Components.get('table7').getVisualization(function(tableView){
         tableView.addCellRenderer(new CustomIconRenderer());
    });
    mvc.Components.get('table7A').getVisualization(function(tableView){
        tableView.addCellRenderer(new CustomIconRenderer());
    });
    mvc.Components.get('table8').getVisualization(function(tableView){
         tableView.addCellRenderer(new CustomIconRenderer());
    });
    mvc.Components.get('table9').getVisualization(function(tableView){
        tableView.addCellRenderer(new CustomIconRenderer());
    });
    mvc.Components.get('table9A').getVisualization(function(tableView){
         tableView.addCellRenderer(new CustomIconRenderer());
    });

    mvc.Components.get('alert_table').getVisualization(function(tableView){
         tableView.addCellRenderer(new CustomIconRenderer());
    });

   
});