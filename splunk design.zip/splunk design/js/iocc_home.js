require([
	'jquery',
	'splunkjs/mvc',
	'splunkjs/mvc/simplexml/ready!'
], function ($, mvc) {
	var tokens = mvc.Components.get("submitted");
    tokens.set("showpanel1", "true");
    $("#panel_row").css('width', '225%');
	$("#forwardclick").css("pointer-events","none");
    $("#forwardclick").css("fill","#d8d1d1");
	$("#backwardclick").css("cursor","pointer");
	$("#forwardclick").on("click", function (){
		tokens.set("showpanel1", "true");
		 $("#panel_row").css('width', '225%');
		 $("#forwardclick").css("pointer-events","none");
		 $("#backwardclick").css("pointer-events","auto");
		 $("#forwardclick").css("fill","#d8d1d1");
		 $("#backwardclick").css("fill","#303030");
		 $("#backwardclick").css("cursor","pointer");
	});
	$("#backwardclick").on("click", function (){
		tokens.unset("showpanel1");
		 $("#panel_row").css('width', '100%');
		 $("#backwardclick").css("pointer-events","none");
		 $("#forwardclick").css("pointer-events","auto");
		 $("#backwardclick").css("fill","#d8d1d1");
		 $("#forwardclick").css("fill","#303030");
		 $("#forwardclick").css("cursor","pointer");
		 
		
	});
	    

});
