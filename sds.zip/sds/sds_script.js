require([
	'jquery',
	'splunkjs/mvc',
	'splunkjs/mvc/simplexml/ready!'
], function ($, mvc) {
	var tokens = mvc.Components.get("default");
		$("#userdropdown").on("click", function () {
			if ($("#dialog-view12905").css("display") == "none") {
				$("#dialog-view12905").css("display", "block")
			}
			else {
				$("#dialog-view12905").css("display", "none");
			}


		});
    $('#resetsap').on("click", function (){
         	tokens.set("form.system1", "P00");
		tokens.set("form.timepicker.earliest","-4h@h"); 
		tokens.set("form.inctimer.earliest","@d"); 
                tokens.set("form.inctimer.latest","now"); 
		tokens.set("form.timepicker.latest","now");   
		tokens.set("form.server", "*");
                tokens.unset("availability_trend");
                tokens.unset("response_trend");
                tokens.unset("showincidentdetails");
                tokens.unset("closedtrendanalytics");
                tokens.unset("opentrendanalytics");
                tokens.unset("showincidentdesc");
                tokens.unset("showincidentdetailstoday");
                tokens.unset("showincidentdesc");
                tokens.unset("availability_trend1");
                tokens.unset("response_trend1");
                 tokens.unset("availability_trend2");
                tokens.unset("response_trend2");
               tokens.unset("availability_trend3");
                tokens.unset("response_trend3");
               tokens.unset("availability_trend4");
                tokens.unset("response_trend4");
                 tokens.unset("availability_trend5");
                tokens.unset("response_trend5");
                 tokens.unset("availability_trend6");
                tokens.unset("response_trend6");
                 tokens.unset("showincidentdesc");
                 tokens.unset("showservertrend");
                 tokens.unset("showrfctrend");
                 tokens.unset("showhttptrend");
                 tokens.unset("showavailabletrend");
                  tokens.unset("showresponsetrend");
                 tokens.unset("showhttpresponsetrend");
                tokens.unset("tok_is_expiring");
                 tokens.unset("channel_show");
                 tokens.unset("showincidentdesc");
                  tokens.unset("showavailabletrend");

        });

 $('#resetsaptcode1').on("click", function (){
                tokens.set("form.time_tok.earliest","-70m@m");
                tokens.set("form.time_tok.latest","now"); 
                tokens.set("form.system_id","*");
                tokens.set("form.user_tok","*");
                tokens.set("form.progname","*");
                tokens.set("form.env","*");
                tokens.set("form.usrid","*");
                tokens.set("form.client_tok","*");
                tokens.set("form.client_id","*");
       });
 $('#resetsaptcode2').on("click", function (){
                
                tokens.set("form.time_tok.earliest","-1h@h");
                tokens.set("form.time_tok.latest","now");
                tokens.set("form.system_id","*");
                tokens.set("form.client_tok","*");
                tokens.set("form.env","*");
                tokens.set("form.function_module","*");
        });
 $('#resetsaptcode3').on("click", function (){
              
                tokens.set("form.time_tok.earliest","-5m@m");
                tokens.set("form.time_tok.latest","now");
                tokens.set("form.system_id","*");
                tokens.set("form.client_id","*");
                tokens.set("form.env","*");
    });
 $('#resetsappi1').on("click", function (){
              
                tokens.set("form.time_tok.earliest","-60m@m");
                tokens.set("form.time_tok.latest","now");
                tokens.set("form.system_id","*");
                tokens.set("form.direction","*");
                tokens.set("form.env","*");
    });
 $('#resetsappi2').on("click", function (){
              
                tokens.set("form.time_tok.earliest","-60m@m");
                tokens.set("form.time_tok.latest","now");
                tokens.set("form.system_id","*");
                tokens.set("form.direction","*");
                tokens.set("form.env","*");
    });
 $('#resetsappi3').on("click", function (){
              
                tokens.set("form.time_tok.earliest","-60m@m");
                tokens.set("form.time_tok.latest","now");
                tokens.set("form.system_id","*");
                tokens.set("form.env","*");
    });

 $('#resetpim').on("click", function (){
		tokens.set("form.timepicker.earliest","-7d@d"); 
		tokens.set("form.inctimer.earliest","-7d@d"); 
		tokens.set("form.timepicker.latest","now");
                         	tokens.set("form.system1", "P00");
		tokens.set("form.timepicker.earliest","-4h@h"); 
		tokens.set("form.inctimer.earliest","-4h@h"); 
		tokens.set("form.timepicker.latest","now"); 
		tokens.set("form.server", "*");
                tokens.unset("availability_trend");
                tokens.unset("response_trend");
                tokens.unset("showincidentdetails");
                tokens.unset("closedtrendanalytics");
                tokens.unset("opentrendanalytics");
                tokens.unset("showincidentdesc");
                tokens.unset("showincidentdetailstoday");
                tokens.unset("showincidentdesc");
                tokens.unset("availability_trend1");
                tokens.unset("response_trend1");
                 tokens.unset("availability_trend2");
                tokens.unset("response_trend2");
               tokens.unset("availability_trend3");
                tokens.unset("response_trend3");
               tokens.unset("availability_trend4");
                tokens.unset("response_trend4");
                 tokens.unset("availability_trend5");
                tokens.unset("response_trend5");
                 tokens.unset("availability_trend6");
                tokens.unset("response_trend6");
                 tokens.unset("showincidentdesc");
                 tokens.unset("showservertrend");
                 tokens.unset("showrfctrend");
                 tokens.unset("showhttptrend");
                 tokens.unset("showavailabletrend");
                  tokens.unset("showresponsetrend");
                 tokens.unset("showhttpresponsetrend");
                tokens.unset("tok_is_expiring");
                 tokens.unset("channel_show");
                 tokens.unset("showincidentdesc");
                 tokens.unset("showavailabletrend");
		    });

$('#resetheat').on("click", function (){
         	
		tokens.set("form.date.earliest","-3mon@mon"); 
		
		tokens.set("form.timepicker.latest","now"); 
		    });


		
	$("#resetjda").on("click", function (){
		tokens.set("form.batchtype", "*");
		tokens.set("form.processname", "*");
		tokens.set("form.source", "*");
		 tokens.set("form.date.earliest","@d"); 
		 tokens.set("form.date.latest","now");
	});
	$("#resetrexis").on("click", function (){
		 tokens.set("form.inctimer.earliest","@d"); 
		 tokens.set("form.inctimer.latest","now");
			});

	
	$("#resetrpa").on("click", function (){
		 tokens.set("form.date.earliest","-24h@h"); 
		 tokens.set("form.date.latest","now");
		tokens.set("form.process_name", "All");
		tokens.set("form.robot", "All");
	});
	$("#resetuser").on("click", function (){
        tokens.set("form.date.earliest","@d"); 
		 tokens.set("form.date.latest","now");
		tokens.set("form.path", "*");

	});
	

});
$("#backbutton").click(function () {
	$('#backRow').css({
		"width": "315px",
		"z-index": "2"
	});
	$('#fixed_row').css({
		"z-index": "0"
	});
	$("#closeButton1").show();
	$("#backbutton").show();
	
	
});

$("#filterButton").click(function () {
	$('#filterRow').css({
		"width": "315px",
		"z-index": "2"
	});
	$('#fixed_row').css({
		"z-index": "0"
	});
	$("#closeButton").show();
	$("#filterButton").show();
	$("#filterButton").addClass("activefilter");
	
});
$("#closeButton").click(function () {
	$('#filterRow').css({
		"width": "0%",
		"z-index": "1"
	});
	$('#fixed_row').css({
		"z-index": "3"
	});

	$("#closeButton").hide();
	$("#filterButton").show();
	$("#filterButton").removeClass("activefilter");
});

$("#closeButton1").click(function () {
	$('#backRow').css({
		"width": "0%",
		"z-index": "1"
	});
	$('#fixed_row').css({
		"z-index": "3"
	});

	$("#closeButton1").hide();
	$("#backbutton").show();
	});

$("#homeButton").click(function () {
	window.location.href="https://rm2lv149973.mah.roche.com:8000/en-US/app/iocc-sre-ui/intelligent_command_center"	
});

$("#resetmyalert").click(function () {
	window.location.href="https://rm2lv149973.mah.roche.com:8000/en-US/app/iocc-sre-ui/myalert_call_statistics"	
});
require([
	'jquery',
	'splunkjs/mvc',
	'splunkjs/mvc/simplexml/ready!'
], function ($, mvc) {
	var tokens = mvc.Components.get("default");
    $('#resetsap').on("click", function (){
         	tokens.set("form.system1", "P00");
		tokens.set("form.timepicker.earliest","-4h@h"); 
		tokens.set("form.inctimer.earliest","-4h@h"); 
		tokens.set("form.timepicker.latest","now"); 
		tokens.set("form.server", "*");
     });

	 $('#resetpim').on("click", function (){
         	
		tokens.set("form.timepicker.earliest","-7d@d"); 
		tokens.set("form.inctimer.earliest","-7d@d"); 
		tokens.set("form.timepicker.latest","now"); 
		    });

$('#resetheat').on("click", function (){
         	
		tokens.set("form.date.earliest","-3mon@mon"); 
		
		tokens.set("form.timepicker.latest","now"); 
		    });


		
	$("#resetjda").on("click", function (){
		tokens.set("form.batchtype", "*");
		tokens.set("form.processname", "*");
		tokens.set("form.source", "*");
		 tokens.set("form.date.earliest","@d"); 
		 tokens.set("form.date.latest","now");
	});
	
	$("#resetrpa").on("click", function (){
		 tokens.set("form.date.earliest","-24h@h"); 
		 tokens.set("form.date.latest","now");
		tokens.set("form.process_name", "All");
		tokens.set("form.robot", "All");
	});
	$("#resetuser").on("click", function (){
        tokens.set("form.date.earliest","@d"); 
		 tokens.set("form.date.latest","now");
		tokens.set("form.path", "*");

	});
	

});
$("#filterButton").click(function () {
	$('#filterRow').css({
		"width": "315px",
		"z-index": "2"
	});
	$('#fixed_row').css({
		"z-index": "0"
	});
	$("#closeButton").show();
	$("#filterButton").show();
	$("#filterButton").addClass("activefilter");

});
$("#closeButton").click(function () {
	$('#filterRow').css({
		"width": "0%",
		"z-index": "1"
	});
	$('#fixed_row').css({
		"z-index": "3"
	});

	$("#closeButton").hide();
	$("#filterButton").show();
	$("#filterButton").removeClass("activefilter");
});

$("#homeButton").click(function () {
	window.location.href="/app/iocc-sre-ui/intelligent_command_center"	
});

$("#resetmyalert").click(function () {
	window.location.href="/app/iocc-sre-ui/myalert_call_statistics"	
});
function setupMultiInput(instance_id) {

      // Get multiselect
      var multi = mvc.Components.get(instance_id);

      // On change, check selection
      multi.on("change", (selectedValues) => {

        console.log("selectedValues",selectedValues);

      });
    }


document.onreadystatechange = function() { 
    if (document.readyState !== "complete") { 
        document.querySelector("body").visibility = "hidden"; 
        //document.querySelector("#loader").style.visibility = "visible"; 
    } else { 
        //document.querySelector("#loader").style.display = "none"; 
        document.querySelector("body").visibility = "visible"; 
    } 
};
var TabBlock = {
	s: {
		animLen: 200
	},

	init: function () {
		TabBlock.bindUIActions();
		TabBlock.hideInactive();
	},

	bindUIActions: function () {
		$('.tabBlock-tabs').on('click', '.tabBlock-tab', function () {
			TabBlock.switchTab($(this));
		});
	},

	hideInactive: function () {
		var $tabBlocks = $('.tabBlock');

		$tabBlocks.each(function (i) {
			var
				$tabBlock = $($tabBlocks[i]),
				$panes = $tabBlock.find('.tabBlock-pane'),
				$activeTab = $tabBlock.find('.tabBlock-tab.is-active');

			$panes.hide();
			$($panes[$activeTab.index()]).show();
		});
	},

	switchTab: function ($tab) {
		var $context = $tab.closest('.tabBlock');

		if (!$tab.hasClass('is-active')) {
			$tab.siblings().removeClass('is-active');
			$tab.addClass('is-active');

			TabBlock.showPane($tab.index(), $context);
		}
	},

	showPane: function (i, $context) {
		var $panes = $context.find('.tabBlock-pane');

		// Normally I'd frown at using jQuery over CSS animations, but we can't transition between unspecified variable heights, right? If you know a better way, I'd love a read it in the comments or on Twitter @johndjameson
		$panes.slideUp(TabBlock.s.animLen);
		$($panes[i]).slideDown(TabBlock.s.animLen);
	}
};

$(function () {
	TabBlock.init();
});

